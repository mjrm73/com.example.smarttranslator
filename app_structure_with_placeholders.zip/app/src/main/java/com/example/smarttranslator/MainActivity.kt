package com.example.smarttranslator

class MainActivity {
    // Placeholder MainActivity
}