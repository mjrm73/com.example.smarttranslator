package com.example.smarttranslator

class OverlayWebViewService {
    // Placeholder OverlayWebViewService
}